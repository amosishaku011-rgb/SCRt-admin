import { useState, useEffect } from "react";

const DATA_VERSION = "v6";
const db = {
  async get(k)   { try { const v=localStorage.getItem(k); return v?JSON.parse(v):null; } catch{return null;} },
  async set(k,v) { try { localStorage.setItem(k,JSON.stringify(v)); } catch{} },
};

const SEED_SCHOOLS = [
  {id:"uic",name:"University of Illinois Chicago",short:"UIC",type:"university"},
  {id:"illinois",name:"Univ. of Illinois Urbana-Champaign",short:"UIUC",type:"university"},
  {id:"northwestern",name:"Northwestern University",short:"NU",type:"university"},
  {id:"depaul",name:"DePaul University",short:"DePaul",type:"university"},
];
const SEED_PROGRAMS = [
  {id:"che",name:"Chemical Engineering",school:"uic",totalCredits:132,icon:"⚗️"},
  {id:"cs",name:"Computer Science",school:"uic",totalCredits:120,icon:"💻"},
  {id:"business",name:"Business Administration",school:"uic",totalCredits:120,icon:"📊"},
  {id:"nursing",name:"Nursing (BSN)",school:"uic",totalCredits:128,icon:"🏥"},
  {id:"mecheng",name:"Mechanical Engineering",school:"illinois",totalCredits:130,icon:"⚙️"},
  {id:"psychology",name:"Psychology",school:"northwestern",totalCredits:120,icon:"🧠"},
  {id:"finance",name:"Finance",school:"depaul",totalCredits:120,icon:"💰"},
];

const ADMINS = {
  "admin@uic.edu":         {password:"uic2024",   schoolId:"uic",         schoolName:"University of Illinois Chicago", schoolType:"university"},
  "admin@illinois.edu":    {password:"uiuc2024",  schoolId:"illinois",    schoolName:"UIUC",                          schoolType:"university"},
  "admin@northwestern.edu":{password:"nu2024",    schoolId:"northwestern",schoolName:"Northwestern University",       schoolType:"university"},
  "admin@depaul.edu":      {password:"depaul2024",schoolId:"depaul",      schoolName:"DePaul University",             schoolType:"university"},
};

const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Inter:wght@300;400;500;600&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg: #f6f7fb; --bg1: #ffffff; --bg2: #f0f1f8; --bg3: #e8eaf5;
    --border: #e2e4f0; --border-hi: #c8cbdf;
    --text0: #1a1a2e; --text1: #3d3d5c; --text2: #7070a0; --text3: #a0a0c0;
    --accent: #6c63ff; --accent-light: rgba(108,99,255,0.08);
    --green: #22c55e; --green-light: rgba(34,197,94,0.08);
    --red: #ef4444; --red-light: rgba(239,68,68,0.06);
    --radius: 12px; --radius-sm: 8px;
  }
  html { font-size: 16px; }
  body { background: var(--bg); font-family: 'Inter', sans-serif; color: var(--text0); -webkit-font-smoothing: antialiased; }
  input, select, button { font-family: 'Inter', sans-serif; }
  input::placeholder { color: var(--text3); }
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-thumb { background: var(--border-hi); border-radius: 4px; }

  .app { min-height: 100vh; background: var(--bg); }

  /* Login */
  .login-wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px; background: linear-gradient(135deg, #0a0a1a 0%, #1a1a3e 100%); }
  .login-card { width: 100%; max-width: 420px; background: white; border-radius: 20px; padding: 40px; box-shadow: 0 24px 80px rgba(0,0,0,0.3); }
  .login-logo { display: flex; align-items: center; gap: 10px; margin-bottom: 32px; }
  .login-logo-mark { width: 40px; height: 40px; border-radius: 10px; background: linear-gradient(135deg, #6c63ff, #ff6b6b); display: flex; align-items: center; justify-content: center; font-size: 20px; }
  .login-logo-text { font-family: 'Syne', sans-serif; font-size: 22px; font-weight: 800; color: var(--text0); }
  .login-logo-sub { font-size: 10px; color: var(--text3); letter-spacing: 0.1em; text-transform: uppercase; }
  .login-title { font-family: 'Syne', sans-serif; font-size: 24px; font-weight: 800; margin-bottom: 6px; }
  .login-sub { font-size: 13px; color: var(--text2); margin-bottom: 28px; line-height: 1.5; }
  .field { margin-bottom: 16px; }
  .field-lbl { display: block; font-size: 11px; font-weight: 600; color: var(--text2); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 6px; }
  .field-input { width: 100%; padding: 12px 14px; border-radius: var(--radius-sm); background: var(--bg2); border: 1px solid var(--border); color: var(--text0); font-size: 14px; outline: none; transition: border-color 0.2s; }
  .field-input:focus { border-color: var(--accent); background: white; }
  .login-btn { width: 100%; padding: 14px; border-radius: var(--radius); background: linear-gradient(135deg, #6c63ff, #8b5cf6); color: white; font-size: 14px; font-weight: 600; border: none; cursor: pointer; margin-top: 4px; transition: opacity 0.2s; letter-spacing: 0.02em; }
  .login-btn:hover { opacity: 0.9; }
  .login-err { font-size: 12px; color: var(--red); margin-bottom: 12px; padding: 10px 12px; background: var(--red-light); border-radius: var(--radius-sm); }
  .login-demos { margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--border); }
  .login-demos-lbl { font-size: 10px; color: var(--text3); text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 10px; font-weight: 600; }
  .demo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
  .demo-btn { padding: 8px 10px; border-radius: var(--radius-sm); background: var(--bg2); border: 1px solid var(--border); cursor: pointer; text-align: left; transition: all 0.15s; }
  .demo-btn:hover { border-color: var(--accent); background: var(--accent-light); }
  .demo-school { font-size: 12px; font-weight: 600; color: var(--text0); }
  .demo-email { font-size: 10px; color: var(--text3); margin-top: 1px; }

  /* Register */
  .reg-link { text-align: center; margin-top: 20px; font-size: 12px; color: var(--text2); }
  .reg-link button { background: none; border: none; color: var(--accent); cursor: pointer; font-size: 12px; text-decoration: underline; }
  .type-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 16px; }
  .type-card { padding: 12px; border-radius: var(--radius-sm); border: 2px solid var(--border); background: var(--bg2); cursor: pointer; user-select: none; transition: all 0.15s; }
  .type-card.active { border-color: var(--accent); background: var(--accent-light); }
  .type-card-name { font-size: 12px; font-weight: 600; color: var(--text0); margin-bottom: 2px; }
  .type-card.active .type-card-name { color: var(--accent); }
  .type-card-desc { font-size: 10px; color: var(--text3); line-height: 1.4; }
  .success-card { text-align: center; padding: 20px 0; }
  .success-icon { font-size: 40px; margin-bottom: 12px; }
  .success-title { font-family: 'Syne', sans-serif; font-size: 20px; font-weight: 800; margin-bottom: 8px; }
  .success-sub { font-size: 13px; color: var(--text2); margin-bottom: 20px; line-height: 1.6; }

  /* Dashboard layout */
  .dash { display: flex; min-height: 100vh; }
  .sidebar { width: 260px; background: var(--text0); flex-shrink: 0; display: flex; flex-direction: column; padding: 24px 0; }
  .sidebar-logo { display: flex; align-items: center; gap: 10px; padding: 0 20px 24px; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 20px; }
  .sidebar-logo-mark { width: 32px; height: 32px; border-radius: 8px; background: linear-gradient(135deg, #6c63ff, #ff6b6b); display: flex; align-items: center; justify-content: center; font-size: 16px; }
  .sidebar-logo-text { font-family: 'Syne', sans-serif; font-size: 17px; font-weight: 800; color: white; }
  .sidebar-logo-sub { font-size: 8px; color: rgba(255,255,255,0.3); text-transform: uppercase; letter-spacing: 0.1em; }
  .sidebar-school { padding: 0 20px 20px; border-bottom: 1px solid rgba(255,255,255,0.08); margin-bottom: 16px; }
  .sidebar-school-name { font-family: 'Syne', sans-serif; font-size: 14px; font-weight: 700; color: white; margin-bottom: 4px; }
  .sidebar-badge { display: inline-block; font-size: 9px; padding: 2px 8px; border-radius: 100px; background: rgba(108,99,255,0.3); color: #a599ff; text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600; }
  .sidebar-email { font-size: 10px; color: rgba(255,255,255,0.3); margin-top: 4px; }
  .sidebar-nav { flex: 1; padding: 0 12px; }
  .sidebar-link { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: var(--radius-sm); cursor: pointer; transition: all 0.15s; margin-bottom: 2px; border: none; background: transparent; width: 100%; text-align: left; color: rgba(255,255,255,0.5); font-size: 13px; font-family: 'Inter', sans-serif; }
  .sidebar-link:hover { background: rgba(255,255,255,0.06); color: rgba(255,255,255,0.8); }
  .sidebar-link.active { background: rgba(108,99,255,0.25); color: white; }
  .sidebar-link-icon { font-size: 16px; flex-shrink: 0; }
  .sidebar-signout { padding: 16px 20px 0; border-top: 1px solid rgba(255,255,255,0.08); margin-top: auto; }
  .signout-btn { display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-radius: var(--radius-sm); cursor: pointer; color: rgba(255,255,255,0.4); font-size: 12px; background: transparent; border: none; font-family: 'Inter', sans-serif; width: 100%; transition: all 0.15s; }
  .signout-btn:hover { color: rgba(255,255,255,0.7); background: rgba(255,255,255,0.05); }

  /* Main */
  .main { flex: 1; padding: 32px; overflow-y: auto; max-width: 900px; }
  .main-header { margin-bottom: 28px; }
  .main-title { font-family: 'Syne', sans-serif; font-size: 26px; font-weight: 800; color: var(--text0); margin-bottom: 4px; }
  .main-sub { font-size: 13px; color: var(--text2); line-height: 1.5; }

  /* Info note */
  .info-note { padding: 12px 16px; border-radius: var(--radius-sm); background: var(--accent-light); border: 1px solid rgba(108,99,255,0.2); font-size: 12px; color: var(--text1); line-height: 1.6; margin-bottom: 24px; }

  /* Cards */
  .content-card { background: white; border-radius: var(--radius); border: 1px solid var(--border); padding: 20px; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
  .content-card-title { font-family: 'Syne', sans-serif; font-size: 15px; font-weight: 700; color: var(--text0); margin-bottom: 16px; display: flex; align-items: center; justify-content: space-between; }

  /* Program list */
  .prog-row { display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: var(--radius-sm); border: 1px solid var(--border); background: var(--bg2); margin-bottom: 8px; }
  .prog-row-icon { font-size: 20px; flex-shrink: 0; }
  .prog-row-info { flex: 1; }
  .prog-row-name { font-size: 14px; font-weight: 600; color: var(--text0); }
  .prog-row-meta { font-size: 11px; color: var(--text3); margin-top: 1px; }
  .prog-row-actions { display: flex; align-items: center; gap: 6px; }

  /* Buttons */
  .btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 100px; font-size: 12px; font-weight: 600; border: none; cursor: pointer; transition: all 0.15s; font-family: 'Inter', sans-serif; }
  .btn-primary { background: var(--accent); color: white; }
  .btn-primary:hover { background: #5a52e0; }
  .btn-outline { background: transparent; color: var(--accent); border: 1px solid var(--accent); }
  .btn-outline:hover { background: var(--accent-light); }
  .btn-danger { background: transparent; color: var(--red); border: 1px solid rgba(239,68,68,0.3); }
  .btn-danger:hover { background: var(--red-light); }
  .btn-sm { padding: 6px 12px; font-size: 11px; }

  /* Form */
  .form-grid { display: grid; gap: 12px; margin-bottom: 16px; }
  .form-grid-2 { grid-template-columns: 1fr 1fr; }
  .form-grid-3 { grid-template-columns: 90px 1fr 60px; }
  .form-lbl { display: block; font-size: 10px; font-weight: 600; color: var(--text2); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 5px; }
  .form-input { width: 100%; padding: 10px 12px; border-radius: var(--radius-sm); background: var(--bg); border: 1px solid var(--border); color: var(--text0); font-size: 13px; outline: none; transition: border-color 0.2s; }
  .form-input:focus { border-color: var(--accent); }
  select.form-input { cursor: pointer; }

  /* Toggle */
  .toggle-wrap { display: flex; align-items: center; gap: 10px; cursor: pointer; user-select: none; }
  .toggle-track { width: 36px; height: 20px; border-radius: 10px; background: var(--border-hi); position: relative; flex-shrink: 0; transition: background 0.2s; }
  .toggle-track.on { background: var(--accent); }
  .toggle-thumb { width: 14px; height: 14px; border-radius: 50%; background: white; position: absolute; top: 3px; left: 3px; transition: left 0.2s; box-shadow: 0 1px 4px rgba(0,0,0,0.2); }
  .toggle-track.on .toggle-thumb { left: 19px; }
  .toggle-label { font-size: 13px; color: var(--text1); }

  /* Item list */
  .item-list { display: flex; flex-direction: column; gap: 6px; max-height: 220px; overflow-y: auto; margin-bottom: 16px; }
  .item-row { display: flex; align-items: center; gap: 8px; padding: 9px 12px; border-radius: var(--radius-sm); background: var(--bg2); border: 1px solid var(--border); }
  .item-code { font-size: 11px; font-weight: 700; color: var(--accent); width: 75px; flex-shrink: 0; font-family: 'Syne', sans-serif; }
  .item-name { font-size: 12px; color: var(--text1); flex: 1; }
  .item-tag { font-size: 10px; color: var(--text3); background: var(--bg3); padding: 2px 8px; border-radius: 100px; flex-shrink: 0; white-space: nowrap; }
  .item-tag.green { color: var(--green); background: var(--green-light); }
  .item-tag.red { color: var(--red); background: var(--red-light); }
  .del-btn { background: none; border: none; color: var(--text3); cursor: pointer; padding: 2px; font-size: 14px; transition: color 0.15s; flex-shrink: 0; }
  .del-btn:hover { color: var(--red); }

  /* Program selector pills */
  .prog-pills { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 16px; }
  .prog-pill { padding: 6px 14px; border-radius: 100px; border: 1px solid var(--border); background: var(--bg2); color: var(--text2); font-size: 12px; cursor: pointer; transition: all 0.15s; }
  .prog-pill:hover { border-color: var(--accent); color: var(--accent); }
  .prog-pill.active { background: var(--accent-light); border-color: var(--accent); color: var(--accent); font-weight: 600; }

  /* Stats row */
  .stats-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 24px; }
  .stat-card { background: white; border-radius: var(--radius); border: 1px solid var(--border); padding: 16px 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
  .stat-n { font-family: 'Syne', sans-serif; font-size: 28px; font-weight: 800; color: var(--accent); }
  .stat-l { font-size: 11px; color: var(--text3); text-transform: uppercase; letter-spacing: 0.06em; margin-top: 2px; }

  /* Divider */
  .divider { height: 1px; background: var(--border); margin: 16px 0; }

  /* Empty */
  .empty { color: var(--text3); font-size: 13px; padding: 16px 0; }

  /* Error/success msg */
  .msg-err { font-size: 12px; color: var(--red); padding: 10px 12px; background: var(--red-light); border-radius: var(--radius-sm); margin-bottom: 12px; }
  .msg-ok  { font-size: 12px; color: var(--green); padding: 10px 12px; background: var(--green-light); border-radius: var(--radius-sm); margin-bottom: 12px; }

  /* Animations */
  @keyframes fadeUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
  .fade { animation: fadeUp 0.3s ease; }

  /* Mobile */
  @media (max-width: 700px) {
    .dash { flex-direction: column; }
    .sidebar { width: 100%; padding: 16px 0; }
    .sidebar-nav { display: flex; overflow-x: auto; padding: 0 12px; }
    .sidebar-signout { display: none; }
    .main { padding: 16px; }
    .form-grid-3 { grid-template-columns: 1fr 1fr; }
    .stats-row { grid-template-columns: 1fr 1fr; }
  }
`;

// ─── Admin Login ──────────────────────────────────────────────────────────────
function Login({onLogin, onAddSchool}) {
  const [mode,setMode]   = useState("login");
  const [email,setEmail] = useState(""); const [pass,setPass]=useState(""); const [err,setErr]=useState("");
  const [rName,setRName] = useState(""); const [rType,setRType]=useState("university");
  const [rEmail,setREmail]=useState(""); const [rPass,setRPass]=useState(""); const [rPass2,setRPass2]=useState("");
  const [rErr,setRErr]   = useState(""); const [rOk,setROk]=useState(false); const [busy,setBusy]=useState(false);

  const login = async () => {
    setErr("");
    const k = email.toLowerCase().trim();
    if(ADMINS[k]&&ADMINS[k].password===pass){onLogin({email:k,...ADMINS[k]});return;}
    const stored = await db.get("scrt:accounts")||{};
    const acc = stored[k];
    if(acc&&acc.password===pass){onLogin({email:k,...acc});return;}
    setErr("Incorrect email or password.");
  };

  const register = async () => {
    setRErr("");
    if(!rName.trim())           {setRErr("School name required.");return;}
    if(!rEmail.includes("@"))   {setRErr("Enter a valid email.");return;}
    if(rPass.length<6)          {setRErr("Password must be 6+ characters.");return;}
    if(rPass!==rPass2)          {setRErr("Passwords do not match.");return;}
    const k = rEmail.toLowerCase().trim();
    const stored = await db.get("scrt:accounts")||{};
    if(stored[k]||ADMINS[k])    {setRErr("Email already registered.");return;}
    setBusy(true);
    const schoolId = rName.trim().toLowerCase().replace(/\W+/g,"_")+"_"+Date.now();
    const acc = {password:rPass, schoolId, schoolName:rName.trim(), schoolType:rType};
    stored[k] = acc;
    await db.set("scrt:accounts", stored);
    onAddSchool({id:schoolId, name:rName.trim(), short:rName.trim().slice(0,6), type:rType});
    setBusy(false); setROk(true);
  };

  return (
    <div className="login-wrap">
      <div className="login-card fade">
        <div className="login-logo">
          <div className="login-logo-mark">🎓</div>
          <div>
            <div className="login-logo-text">SCRt Admin</div>
            <div className="login-logo-sub">School Backend Portal</div>
          </div>
        </div>

        {/* Tabs */}
        <div style={{display:"flex",gap:4,marginBottom:24,background:"#f0f1f8",padding:4,borderRadius:10}}>
          {[["login","Sign In"],["register","Create Account"]].map(([id,lbl])=>(
            <button key={id} onClick={()=>{setMode(id);setErr("");setRErr("");setROk(false);}}
              style={{flex:1,padding:"9px 0",borderRadius:8,border:"none",background:mode===id?"white":"transparent",color:mode===id?"#6c63ff":"#7070a0",fontFamily:"Inter,sans-serif",fontSize:13,fontWeight:mode===id?600:400,cursor:"pointer",boxShadow:mode===id?"0 2px 8px rgba(0,0,0,0.08)":"none"}}>
              {lbl}
            </button>
          ))}
        </div>

        {mode==="login" && <>
          <div className="field"><label className="field-lbl">Email</label><input className="field-input" value={email} onChange={e=>{setEmail(e.target.value);setErr("");}} placeholder="admin@yourschool.edu"/></div>
          <div className="field"><label className="field-lbl">Password</label><input className="field-input" type="password" value={pass} onChange={e=>{setPass(e.target.value);setErr("");}} placeholder="••••••••"/></div>
          {err && <div className="login-err">{err}</div>}
          <button className="login-btn" onClick={login}>Sign In →</button>
          <div className="login-demos">
            <div className="login-demos-lbl">Demo accounts — click to fill</div>
            <div className="demo-grid">
              {Object.entries(ADMINS).map(([em,a])=>(
                <button key={em} className="demo-btn" onClick={()=>{setEmail(em);setPass(a.password);setErr("");}}>
                  <div className="demo-school">{a.schoolName.split(" ").slice(-1)[0]}</div>
                  <div className="demo-email">{em}</div>
                </button>
              ))}
            </div>
          </div>
        </>}

        {mode==="register" && (rOk ? (
          <div className="success-card fade">
            <div className="success-icon">🎉</div>
            <div className="success-title">Account Created!</div>
            <p className="success-sub"><strong>{rName}</strong> is ready. Sign in with <strong>{rEmail}</strong> to start uploading your data.</p>
            <button className="login-btn" onClick={()=>{setMode("login");setEmail(rEmail);setPass(rPass);setROk(false);}}>Go to Sign In →</button>
          </div>
        ) : <>
          <div className="field"><label className="field-lbl">Institution Name</label><input className="field-input" value={rName} onChange={e=>{setRName(e.target.value);setRErr("");}} placeholder="e.g. College of DuPage"/></div>
          <div style={{marginBottom:16}}>
            <label className="field-lbl">Institution Type</label>
            <div className="type-grid">
              {[{id:"community",name:"Community College",desc:"Upload courses & transfer equivalencies"},{id:"university",name:"4-Year University",desc:"Upload degree requirements per program"}].map(t=>(
                <div key={t.id} onClick={()=>setRType(t.id)} className={`type-card ${rType===t.id?"active":""}`}>
                  <div className="type-card-name">{t.name}</div>
                  <div className="type-card-desc">{t.desc}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="field"><label className="field-lbl">Admin Email</label><input className="field-input" value={rEmail} onChange={e=>{setREmail(e.target.value);setRErr("");}} placeholder="admin@school.edu"/></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:4}}>
            <div className="field"><label className="field-lbl">Password</label><input className="field-input" type="password" value={rPass} onChange={e=>{setRPass(e.target.value);setRErr("");}} placeholder="Min. 6 chars"/></div>
            <div className="field"><label className="field-lbl">Confirm</label><input className="field-input" type="password" value={rPass2} onChange={e=>{setRPass2(e.target.value);setRErr("");}} placeholder="Repeat"/></div>
          </div>
          {rErr && <div className="login-err">{rErr}</div>}
          <button className="login-btn" onClick={register} disabled={busy} style={{opacity:busy?0.6:1}}>{busy?"Creating…":"Create Account →"}</button>
        </>)}

        <div className="reg-link">
          {mode==="login"
            ? <><span>New school? </span><button onClick={()=>setMode("register")}>Create an account</button></>
            : <button onClick={()=>setMode("login")}>← Back to Sign In</button>}
        </div>
      </div>
    </div>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────
function Dashboard({admin, programs, ccCourses, requirements, onUpdate, onLogout}) {
  const mine   = programs.filter(p=>p.school===admin.schoolId);
  const isUni  = admin.schoolType==="university";
  const [tab,setTab]   = useState("overview");
  const [prog,setProg] = useState(null);
  const [st,setSt]     = useState("");

  // Program form
  const [pName,setPName]=useState(""); const [pCr,setPCr]=useState("120"); const [pIcon,setPIcon]=useState("📚");

  // CC Course form
  const [cCode,setCCode]=useState(""); const [cName,setCName]=useState(""); const [cCr,setCCr]=useState("3");
  const [cXfer,setCXfer]=useState(true); const [cMapsTo,setCMapsTo]=useState("");

  // Requirement form
  const [rCode,setRCode]=useState(""); const [rName,setRName]=useState(""); const [rCr,setRCr]=useState("3");
  const [rEquiv,setREquiv]=useState(""); const [rSem,setRSem]=useState("1");

  const save = async (myProgs,nc,nr) => {
    setSt("saving");
    const others = programs.filter(p=>p.school!==admin.schoolId);
    await onUpdate([...others,...myProgs], nc, nr);
    setSt("saved"); setTimeout(()=>setSt(""),2500);
  };

  const addProg  = () => { if(!pName.trim())return; const id=pName.toLowerCase().replace(/\W+/g,"_")+"_"+admin.schoolId+"_"+Date.now(); save([...mine,{id,name:pName.trim(),school:admin.schoolId,totalCredits:parseInt(pCr)||120,icon:pIcon}],ccCourses,requirements); setPName("");setPCr("120"); };
  const delProg  = id => { const nc={...ccCourses};delete nc[id]; const nr={...requirements};delete nr[id]; save(mine.filter(p=>p.id!==id),nc,nr); if(prog?.id===id)setProg(null); };
  const addCourse= () => { if(!cCode.trim()||!cName.trim()||!prog)return; const c={code:cCode.trim().toUpperCase(),name:cName.trim(),credits:parseInt(cCr)||3,transferable:cXfer,mapsTo:cXfer?(cMapsTo.trim()||null):null}; save(mine,{...ccCourses,[prog.id]:[...(ccCourses[prog.id]||[]),c]},requirements); setCCode("");setCName("");setCCr("3");setCMapsTo("");setCXfer(true); };
  const delCourse= code => { save(mine,{...ccCourses,[prog.id]:(ccCourses[prog.id]||[]).filter(c=>c.code!==code)},requirements); };
  const addReq   = () => { if(!rCode.trim()||!rName.trim()||!prog)return; const r={code:rCode.trim().toUpperCase(),name:rName.trim(),credits:parseInt(rCr)||3,equiv:rEquiv.trim()||null,semHint:parseInt(rSem)||1}; save(mine,ccCourses,{...requirements,[prog.id]:[...(requirements[prog.id]||[]),r]}); setRCode("");setRName("");setRCr("3");setREquiv("");setRSem("1"); };
  const delReq   = code => { save(mine,ccCourses,{...requirements,[prog.id]:(requirements[prog.id]||[]).filter(r=>r.code!==code)}); };

  const totalCourses = mine.reduce((a,p)=>a+(ccCourses[p.id]||[]).length,0);
  const totalReqs    = mine.reduce((a,p)=>a+(requirements[p.id]||[]).length,0);

  const navItems = [
    {id:"overview", icon:"📊", label:"Overview"},
    {id:"programs", icon:"🎓", label:"Programs"},
    {id:isUni?"requirements":"courses", icon:isUni?"📋":"📚", label:isUni?"Requirements":"Courses"},
  ];

  return (
    <div className="dash fade">
      {/* Sidebar */}
      <div className="sidebar">
        <div className="sidebar-logo">
          <div className="sidebar-logo-mark">🎓</div>
          <div>
            <div className="sidebar-logo-text">SCRt</div>
            <div className="sidebar-logo-sub">Admin Portal</div>
          </div>
        </div>
        <div className="sidebar-school">
          <div className="sidebar-school-name">{admin.schoolName}</div>
          <div className="sidebar-badge">{isUni?"4-Year University":"Community College"}</div>
          <div className="sidebar-email">{admin.email}</div>
        </div>
        <nav className="sidebar-nav">
          {navItems.map(n=>(
            <button key={n.id} onClick={()=>setTab(n.id)} className={`sidebar-link ${tab===n.id?"active":""}`}>
              <span className="sidebar-link-icon">{n.icon}</span>
              {n.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-signout">
          <button className="signout-btn" onClick={onLogout}>
            <span>🚪</span> Sign Out
          </button>
        </div>
      </div>

      {/* Main */}
      <div className="main">
        {/* Save indicator */}
        {st==="saving" && <div style={{position:"fixed",top:16,right:16,background:"#6c63ff",color:"white",padding:"8px 16px",borderRadius:100,fontSize:12,fontWeight:600,zIndex:999}}>Saving…</div>}
        {st==="saved"  && <div style={{position:"fixed",top:16,right:16,background:"#22c55e",color:"white",padding:"8px 16px",borderRadius:100,fontSize:12,fontWeight:600,zIndex:999}}>✓ Saved</div>}

        {/* Overview */}
        {tab==="overview" && <>
          <div className="main-header">
            <div className="main-title">Welcome back 👋</div>
            <div className="main-sub">Manage your institution's data for the SCRt transfer planning app.</div>
          </div>
          <div className="stats-row">
            <div className="stat-card"><div className="stat-n">{mine.length}</div><div className="stat-l">Programs</div></div>
            {isUni
              ? <div className="stat-card"><div className="stat-n">{totalReqs}</div><div className="stat-l">Requirements</div></div>
              : <div className="stat-card"><div className="stat-n">{totalCourses}</div><div className="stat-l">Courses</div></div>}
            <div className="stat-card"><div className="stat-n">{mine.filter(p=>(isUni?(requirements[p.id]||[]).length:(ccCourses[p.id]||[]).length)>0).length}</div><div className="stat-l">Programs with Data</div></div>
          </div>
          <div className="info-note">
            {isUni
              ? "📋 As a 4-year university, upload your degree requirements for each program. The app automatically generates each student's personalized graduation roadmap based on what they've already transferred in."
              : "📋 As a community college, upload the courses your students take. For each course, indicate whether it transfers to a university and what the equivalent course code is at the destination school."}
          </div>
          <div className="content-card">
            <div className="content-card-title">Your Programs</div>
            {mine.length===0 && <p className="empty">No programs yet — go to Programs tab to add one.</p>}
            {mine.map(p=>(
              <div key={p.id} className="prog-row">
                <span className="prog-row-icon">{p.icon||"📚"}</span>
                <div className="prog-row-info">
                  <div className="prog-row-name">{p.name}</div>
                  <div className="prog-row-meta">
                    {p.totalCredits} credits · {isUni?(requirements[p.id]||[]).length+" requirements":(ccCourses[p.id]||[]).length+" courses"}
                  </div>
                </div>
                <button className="btn btn-outline btn-sm" onClick={()=>{setProg(p);setTab(isUni?"requirements":"courses");}}>
                  Edit {isUni?"Requirements":"Courses"}
                </button>
              </div>
            ))}
          </div>
        </>}

        {/* Programs */}
        {tab==="programs" && <>
          <div className="main-header">
            <div className="main-title">Programs 🎓</div>
            <div className="main-sub">Add and manage the degree programs your school offers.</div>
          </div>
          {mine.map(p=>(
            <div key={p.id} className="prog-row">
              <span className="prog-row-icon">{p.icon||"📚"}</span>
              <div className="prog-row-info">
                <div className="prog-row-name">{p.name}</div>
                <div className="prog-row-meta">{p.totalCredits} credits · {isUni?(requirements[p.id]||[]).length+" reqs":(ccCourses[p.id]||[]).length+" courses"}</div>
              </div>
              <div className="prog-row-actions">
                <button className="btn btn-outline btn-sm" onClick={()=>{setProg(p);setTab(isUni?"requirements":"courses");}}>Edit</button>
                <button className="btn btn-danger btn-sm" onClick={()=>delProg(p.id)}>Delete</button>
              </div>
            </div>
          ))}
          {mine.length===0 && <p className="empty">No programs yet.</p>}
          <div className="divider"/>
          <div className="content-card">
            <div className="content-card-title">Add New Program</div>
            <div className="form-grid form-grid-2">
              <div><label className="form-lbl">Program Name</label><input className="form-input" value={pName} onChange={e=>setPName(e.target.value)} placeholder="e.g. Chemical Engineering"/></div>
              <div><label className="form-lbl">Total Credits to Graduate</label><input className="form-input" value={pCr} onChange={e=>setPCr(e.target.value)} placeholder="120"/></div>
            </div>
            <div style={{marginBottom:16}}>
              <label className="form-lbl">Icon</label>
              <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                {["⚗️","💻","📊","🏥","⚙️","🧠","💰","⚖️","🎨","📐","🔬","🌍","📚"].map(ico=>(
                  <button key={ico} onClick={()=>setPIcon(ico)} style={{width:36,height:36,borderRadius:8,border:`2px solid ${pIcon===ico?"#6c63ff":"#e2e4f0"}`,background:pIcon===ico?"rgba(108,99,255,0.1)":"transparent",cursor:"pointer",fontSize:18}}>
                    {ico}
                  </button>
                ))}
              </div>
            </div>
            <button className="btn btn-primary" onClick={addProg}>+ Add Program</button>
          </div>
        </>}

        {/* Courses (CC) */}
        {tab==="courses" && !isUni && <>
          <div className="main-header">
            <div className="main-title">Courses 📚</div>
            <div className="main-sub">Upload the courses your students take and mark which ones transfer to universities.</div>
          </div>
          <div className="prog-pills">
            {mine.map(p=><button key={p.id} onClick={()=>setProg(p)} className={`prog-pill ${prog?.id===p.id?"active":""}`}>{p.icon} {p.name}</button>)}
            {mine.length===0 && <span style={{color:"var(--text3)",fontSize:13}}>Add programs first.</span>}
          </div>
          {prog ? <>
            <div className="content-card">
              <div className="content-card-title">
                {prog.icon} {prog.name}
                <span style={{fontSize:12,color:"var(--text3)",fontWeight:400}}>{(ccCourses[prog.id]||[]).length} courses</span>
              </div>
              <div className="item-list">
                {(ccCourses[prog.id]||[]).map(c=>(
                  <div key={c.code} className="item-row">
                    <span className="item-code">{c.code}</span>
                    <span className="item-name">{c.name}</span>
                    <span className="item-tag">{c.credits}cr</span>
                    <span className={`item-tag ${c.transferable?"green":"red"}`}>{c.transferable?`→ ${c.mapsTo||"?"}`:"no transfer"}</span>
                    <button className="del-btn" onClick={()=>delCourse(c.code)}>🗑</button>
                  </div>
                ))}
                {!(ccCourses[prog.id]||[]).length && <p className="empty">No courses yet.</p>}
              </div>
              <div className="divider"/>
              <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700,marginBottom:12,color:"var(--text0)"}}>Add Course</div>
              <div className="form-grid form-grid-3" style={{marginBottom:12}}>
                <div><label className="form-lbl">CC Code</label><input className="form-input" value={cCode} onChange={e=>setCCode(e.target.value)} placeholder="CHEM 101"/></div>
                <div><label className="form-lbl">Course Name</label><input className="form-input" value={cName} onChange={e=>setCName(e.target.value)} placeholder="General Chemistry I"/></div>
                <div><label className="form-lbl">Credits</label><input className="form-input" value={cCr} onChange={e=>setCCr(e.target.value)} placeholder="5"/></div>
              </div>
              <div style={{display:"flex",gap:16,alignItems:"center",marginBottom:16,flexWrap:"wrap"}}>
                <div className="toggle-wrap" onClick={()=>setCXfer(x=>!x)}>
                  <div className={`toggle-track ${cXfer?"on":""}`}><div className="toggle-thumb"/></div>
                  <span className="toggle-label">{cXfer?"Transfers to university":"Does not transfer"}</span>
                </div>
                {cXfer && <div style={{flex:1,minWidth:160}}>
                  <label className="form-lbl">University Equivalent Code</label>
                  <input className="form-input" value={cMapsTo} onChange={e=>setCMapsTo(e.target.value)} placeholder="e.g. CHEM 112"/>
                </div>}
              </div>
              <button className="btn btn-primary" onClick={addCourse}>+ Add Course</button>
            </div>
          </> : <div className="content-card"><p className="empty">Select a program above to manage its courses.</p></div>}
        </>}

        {/* Requirements (University) */}
        {tab==="requirements" && isUni && <>
          <div className="main-header">
            <div className="main-title">Degree Requirements 📋</div>
            <div className="main-sub">Upload the required courses for each degree. The app uses these to auto-generate student roadmaps.</div>
          </div>
          <div className="prog-pills">
            {mine.map(p=><button key={p.id} onClick={()=>setProg(p)} className={`prog-pill ${prog?.id===p.id?"active":""}`}>{p.icon} {p.name}</button>)}
            {mine.length===0 && <span style={{color:"var(--text3)",fontSize:13}}>Add programs first.</span>}
          </div>
          {prog ? <>
            <div className="content-card">
              <div className="content-card-title">
                {prog.icon} {prog.name}
                <span style={{fontSize:12,color:"var(--text3)",fontWeight:400}}>{(requirements[prog.id]||[]).length} requirements</span>
              </div>
              <div className="item-list">
                {(requirements[prog.id]||[]).map(r=>(
                  <div key={r.code} className="item-row">
                    <span className="item-code">{r.code}</span>
                    <span className="item-name">{r.name}</span>
                    <span className="item-tag">{r.credits}cr</span>
                    <span className="item-tag">Sem {r.semHint}</span>
                    {r.equiv && <span className="item-tag green">if: {r.equiv}</span>}
                    <button className="del-btn" onClick={()=>delReq(r.code)}>🗑</button>
                  </div>
                ))}
                {!(requirements[prog.id]||[]).length && <p className="empty">No requirements yet.</p>}
              </div>
              <div className="divider"/>
              <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700,marginBottom:12,color:"var(--text0)"}}>Add Requirement</div>
              <div className="form-grid form-grid-3" style={{marginBottom:12}}>
                <div><label className="form-lbl">Course Code</label><input className="form-input" value={rCode} onChange={e=>setRCode(e.target.value)} placeholder="CHE 201"/></div>
                <div><label className="form-lbl">Course Name</label><input className="form-input" value={rName} onChange={e=>setRName(e.target.value)} placeholder="Material & Energy Balances"/></div>
                <div><label className="form-lbl">Credits</label><input className="form-input" value={rCr} onChange={e=>setRCr(e.target.value)} placeholder="3"/></div>
              </div>
              <div className="form-grid form-grid-2" style={{marginBottom:16}}>
                <div>
                  <label className="form-lbl">Typical Semester</label>
                  <select className="form-input" value={rSem} onChange={e=>setRSem(e.target.value)}>
                    <option value="1">Semester 1 — Year 3 Fall</option>
                    <option value="2">Semester 2 — Year 3 Spring</option>
                    <option value="3">Semester 3 — Year 4 Fall</option>
                    <option value="4">Semester 4 — Year 4 Spring</option>
                    <option value="5">Semester 5 — Year 5 Fall</option>
                    <option value="6">Semester 6 — Year 5 Spring</option>
                  </select>
                </div>
                <div>
                  <label className="form-lbl">CC Equivalent (optional)</label>
                  <input className="form-input" value={rEquiv} onChange={e=>setREquiv(e.target.value)} placeholder="e.g. CHEM 201 — satisfies this req"/>
                </div>
              </div>
              <button className="btn btn-primary" onClick={addReq}>+ Add Requirement</button>
            </div>
          </> : <div className="content-card"><p className="empty">Select a program above to manage its requirements.</p></div>}
        </>}
      </div>
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function AdminApp() {
  const [admin,setAdmin]   = useState(null);
  const [schools,setSchools]   = useState(SEED_SCHOOLS);
  const [programs,setPrograms] = useState(SEED_PROGRAMS);
  const [ccCourses,setCcCourses]   = useState({});
  const [requirements,setRequirements] = useState({});
  const [ready,setReady]   = useState(false);

  useEffect(()=>{
    (async()=>{
      const ss=await db.get("scrt:schools");      if(ss) setSchools(ss);
      const sp=await db.get("scrt:programs");     if(sp) setPrograms(sp);
      const sc=await db.get("scrt:courses");      if(sc) setCcCourses(sc);
      const sr=await db.get("scrt:requirements"); if(sr) setRequirements(sr);
      setReady(true);
    })();
  },[]);

  const handleUpdate = async (np,nc,nr) => {
    setPrograms(np); setCcCourses(nc); setRequirements(nr);
    await db.set("scrt:programs",np);
    await db.set("scrt:courses",nc);
    await db.set("scrt:requirements",nr);
  };
  const addSchool = async s => {
    const u=[...schools,s]; setSchools(u);
    await db.set("scrt:schools",u);
  };

  return (
    <>
      <style>{CSS}</style>
      {!ready ? (
        <div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"#0a0a1a"}}>
          <p style={{color:"rgba(255,255,255,0.3)",fontFamily:"Inter,sans-serif",fontSize:13}}>Loading…</p>
        </div>
      ) : admin ? (
        <Dashboard
          admin={admin}
          programs={programs}
          ccCourses={ccCourses}
          requirements={requirements}
          onUpdate={handleUpdate}
          onLogout={()=>setAdmin(null)}
        />
      ) : (
        <Login onLogin={a=>setAdmin(a)} onAddSchool={addSchool}/>
      )}
    </>
  );
}
